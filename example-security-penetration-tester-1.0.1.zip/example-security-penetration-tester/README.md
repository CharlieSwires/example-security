# Example Security Penetration Tester

A Java 17 Swing application for authorised, non-destructive security regression
checks against `example-security`.

It checks the origin-level `/health` endpoint, TLS, certificate lifetime, security headers,
server-version disclosure, CSRF issuance, cookie flags, hostile-origin CORS,
TRACE handling, input validation, unauthenticated access controls and optional
test-account login/session/logout behaviour.

It does **not** brute-force passwords, deliver exploit payloads, mutate clinical
records or automate MFA secrets. An automated result is not a professional
penetration-test certificate.

```bash
mvn clean package
java -jar target/example-security-penetration-tester-1.0.0.jar
```

Use a dedicated non-MFA account if you want authenticated checks. Passwords are
held only for the duration of the test and are not written to reports.

