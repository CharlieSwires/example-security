#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
java -jar target/example-security-penetration-tester-1.0.1.jar

