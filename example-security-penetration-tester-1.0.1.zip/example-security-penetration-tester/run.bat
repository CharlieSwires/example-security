@echo off
cd /d "%~dp0"
java -jar target\example-security-penetration-tester-1.0.1.jar

